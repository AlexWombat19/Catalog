from django import forms
from Profesor.models import Profesor

class ProfesorForm(forms.ModelForm):
    class Meta:
        model = Profesor
        fields = ['name', 'subject', 'class_numbers']
        widgets = {
            'class_numbers': forms.CheckboxSelectMultiple,
        }
