from django.db import models
from administrator.models import Class  # Import the Class model

class Profesor(models.Model):
    name = models.CharField(max_length=100)
    subject = models.CharField(max_length=50, choices=[
        ('mathematics', 'Mathematics'),
        ('chemistry', 'Chemistry'),
        ('history', 'History'),
        # Add more subjects as needed
    ])
    class_numbers = models.ManyToManyField(Class, blank=True)

    def __str__(self):
        return self.name
