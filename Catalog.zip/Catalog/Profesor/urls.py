from django.urls import path
from Profesor import views

urlpatterns = [
    path('create_profesor/', views.ProfesorCreateView.as_view(), name='create-profesor'),
]